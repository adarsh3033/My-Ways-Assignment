function App() {
  return (
    <h1 className="text-[48px] text-[red] font-bold">Hello World!!!</h1>
  );
}

export default App;
